chrome.runtime.onMessage.addListener( function ( request, sender, sendResponse ) {
    if ( request.command === "closeTabs" ) {
        chrome.tabs.query( {}, function ( tabs ) {
            let urlsToKeepOpen = request.urls;
            for ( let i = 0; i < tabs.length; i++ ) {
                if ( !urlsToKeepOpen.includes( tabs[ i ].url ) ) {
                    chrome.tabs.remove( tabs[ i ].id );
                }
            }
        } );
    }
} );
