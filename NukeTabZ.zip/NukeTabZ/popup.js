document.getElementById( 'submit' ).addEventListener( 'click', function () {
    let urls = document.getElementById( 'urls' ).value.split( ',' ).map( url => url.trim() );
    chrome.runtime.sendMessage( { command: "closeTabs", urls: urls } );
} );